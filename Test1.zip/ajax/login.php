<?php
	session_start();
	include('../includes/db_config.php');
	include('../classes/class_login.php');
	
	$login=new LOGIN();
	
	if(isset($_POST['mode']) && $_POST['mode']=='UserLogin'){
		$CheckUserLogin=$login->CheckUserLogin($conn,$_POST['txt_username'],$_POST['txt_password']);
		$IsAccessable=mysqli_num_rows($CheckUserLogin);
		$UserData=mysqli_fetch_assoc($CheckUserLogin);
		if($IsAccessable){
			$_SESSION['UserID']=$UserData['user_id'];
			echo json_encode(1);
		}else{
			echo json_encode(0);
		}
	}
	
	
	
?>
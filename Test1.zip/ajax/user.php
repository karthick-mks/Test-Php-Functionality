<?php
	session_start();
	include('../includes/db_config.php');
	include('../classes/class_user.php');
	include('../classes/class_login.php');
	
	$user=new USER();
	$login=new LOGIN();
	
	if(isset($_POST['mode']) && $_POST['mode']=='UserMaster'){
		$checkIsExists=$user->checkIsExists($conn,$_POST['UserName']);
		if($checkIsExists==0){
			$AddUser=$user->AddUser($conn,$_POST['UserName'],$_POST['UserEmail'],$_POST['UserPassword']);
			if($AddUser){
				$AddUserMaster=$login->AddUserMaster($conn,$_POST['UserName'],$_POST['UserPassword']);
				echo json_encode(1);
			}else{
				echo json_encode(0);
			}
		}else{
			echo json_encode(2);
		}
	}
	
	if(isset($_POST['mode']) && $_POST['mode']=='UserMasterEdit'){
		$checkIsExistsEdit=$user->checkIsExistsEdit($conn,$_POST['UserNameEdit'],$_POST['UserId']);
		if($checkIsExistsEdit==0){	
			$old_user=$user->getUserName($conn,$_POST['UserId']);
			$old_pass=$user->getUserPassword($conn,$_POST['UserId']);
			if($_POST['UserPasswordEdit']==''){
				$UpdateUser=$user->UpdateUser1($conn,$_POST['UserNameEdit'],$_POST['UserEmailEdit'],$_POST['UserId']);
				$UpdateUserMaster=$login->UpdateUserMaster1($conn,$_POST['UserNameEdit'],$old_user,$old_pass);
			}else{
				$UpdateUser=$user->UpdateUser2($conn,$_POST['UserNameEdit'],$_POST['UserEmailEdit'],$_POST['UserId'],$_POST['UserPasswordEdit']);
				$UpdateUserMaster=$login->UpdateUserMaster2($conn,$_POST['UserNameEdit'],$_POST['UserPasswordEdit'],$old_user,$old_pass);
			}
			if($UpdateUser){
				echo json_encode(1);
			}else{
				echo json_encode(0);
			}
		}else{
			echo json_encode(2);
		}
	}
	
	if(isset($_POST['mode']) && $_POST['mode']=='ListUserMasterDetails'){
		$ListUserMasterDetails=$user->ListUserMasterDetails($conn);
		$Details=array();
		while($data=mysqli_fetch_array($ListUserMasterDetails)){
			$Details[]=$data;
		}
		echo json_encode($Details);
	}
	
	if(isset($_POST['mode']) && $_POST['mode']=='EditUser'){
		$EditUser=$user->EditUser($conn,$_POST['user_id']);
		$Details=mysqli_fetch_array($EditUser);
		echo json_encode($Details);
	}
	
	
?>
<?php
	class LOGIN{
		
		function AddUserMaster($conn,$username,$password){
			$query="INSERT INTO ".USER_MASTER." (username,password,d_password) VALUES ('".$username."','".md5($password)."','".$password."')";
			$result=mysqli_query($conn,$query);
			return $result;
		}
	
		function UpdateUserMaster1($conn,$username,$old_user,$old_password){
			$query="UPDATE ".USER_MASTER." SET username='".$username."' WHERE username='".$old_user."' AND d_password='".$old_password."'";
			$result=mysqli_query($conn,$query);
			return $result;
		}
	
		function UpdateUserMaster2($conn,$username,$password,$old_user,$old_password){
			$query="UPDATE ".USER_MASTER." SET username='".$username."',password='".md5($password)."',d_password='".$password."' WHERE username='".$old_user."' AND d_password='".$old_password."'";
			$result=mysqli_query($conn,$query);
			return $result;
		}
	
		function CheckUserLogin($conn,$username,$password){
			$query="SELECT * FROM ".USER_MASTER." WHERE username='".$username."' AND password='".md5($password)."' AND isactive=1";
			$result=mysqli_query($conn,$query);
			return $result;
		}
	
	
	}	
?>
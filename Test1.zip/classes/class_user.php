<?php
	class USER{
		
		function checkIsExists($conn,$user_name){
			$query="SELECT COUNT(*) count FROM ".USER." WHERE user_name='".$user_name."' AND isactive=1";
			$result=mysqli_query($conn,$query);
			$result_count=mysqli_fetch_assoc($result);
			return $result_count['count'];
		}
		
		function checkIsExistsEdit($conn,$user_name,$user_id){
			$query="SELECT COUNT(*) count FROM ".USER." WHERE user_name='".$user_name."' AND user_id!='".$user_id."' AND isactive=1";
			$result=mysqli_query($conn,$query);
			$result_count=mysqli_fetch_assoc($result);
			return $result_count['count'];
		}
		
		function AddUser($conn,$user_name,$user_email,$user_password){
			$query="INSERT INTO ".USER." (user_name,user_email,user_password) VALUES ('".$user_name."','".$user_email."','".$user_password."')";
			$result=mysqli_query($conn,$query);
			return $result;
		}
		
		function ListUserMasterDetails($conn){
			$query="SELECT * FROM ".USER." WHERE isactive=1";
			$result=mysqli_query($conn,$query);
			return $result;
		}
	
		function EditUser($conn,$user_id){
			$query="SELECT * FROM ".USER." WHERE user_id='".$user_id."' AND isactive=1";
			$result=mysqli_query($conn,$query);
			return $result;
		}
	
		function getUserName($conn,$user_id){
			$query="SELECT * FROM ".USER." WHERE user_id='".$user_id."' AND isactive=1";
			$result=mysqli_query($conn,$query);
			$result_=mysqli_fetch_assoc($result);
			return $result_['user_name'];
		}
	
		function getUserPassword($conn,$user_id){
			$query="SELECT * FROM ".USER." WHERE user_id='".$user_id."' AND isactive=1";
			$result=mysqli_query($conn,$query);
			$result_=mysqli_fetch_assoc($result);
			return $result_['user_password'];
		}
		
		function UpdateUser1($conn,$user_name,$user_email,$user_id){
			$query="UPDATE ".USER." SET user_name'".$user_name."',user_email='".$user_email."' WHERE user_id='".$user_id."'";
			$result=mysqli_query($conn,$query);
			return 1;
		}
	
		function UpdateUser2($conn,$user_name,$user_email,$user_id,$user_password){
			$query="UPDATE ".USER." SET user_name'".$user_name."',user_email='".$user_email."',user_password='".$user_password."' WHERE user_id='".$user_id."'";
			$result=mysqli_query($conn,$query);
			return 1;
		}
	
	}	
?>
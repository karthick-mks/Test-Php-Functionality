<?php
	session_start();
	if(isset($_SESSION['UserID']) && $_SESSION['UserID']!=''){
		include('common/header.php');
		if(isset($_REQUEST['page']) && ($_REQUEST['page']!='')){
			include('modules/'.$_REQUEST['page'].'/index.php');
		}else{
			include('modules/dashboard/index.php');
		}
	}else{
		include('login/index.php');
	}
	
	include('common/footer.php');
	
?>
<!DOCTYPE html>
<html lang='en' class=''>
	<head>
		<link rel='stylesheet' href='assets/boostrap4.0/css/bootstrap.min.css'>
		<link rel='stylesheet' href='assets/DataTables/datatables.css'>
		
		<script src='assets/jquery3.2.1/jquery.min.js'></script>
		<script src='assets/boostrap4.0/js/bootstrap.min.js'></script>
		<script src='assets/jquery_validation1.19.0/js/jquery.validate.js'></script>
		<script src='assets/DataTables/datatables.js'></script>
		<script src='js/custom.js'></script>
		
	</head>
	<?php
		include('menu.php');
	?>
	<body>
		<div class="container-fluid mt-3">
<?php

$dashboard='active';
$user='';

if(isset($_REQUEST['page']) && $_REQUEST['page']=='user'){
	$user='active';
	$dashboard='';
}

?>

<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
	<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
		<span class="navbar-toggler-icon"></span>
	</button>
	<div class="collapse navbar-collapse" id="navbarText">
		<ul class="navbar-nav mr-auto">
			<li class="nav-item <?php echo $dashboard; ?>">
				<a class="nav-link" href="?page=dashboard">Dashboard</a>
			</li>
			<li class="nav-item <?php echo $user; ?>">
				<a class="nav-link" href="?page=user">User</a>
			</li>
			<li class="nav-item">
				<a class="nav-link" href="#">Pricing</a>
			</li>
		</ul>
		<span class="navbar-text">
			<a class="" href="?page=logout">Logout</a>
		</span>
	</div>
</nav>
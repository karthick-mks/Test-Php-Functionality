<?php
	
	$hostname="localhost";
	$username="root";
	$password="";
	$databasename="db_test1";
	
	$table_prefix="tbl_";
	
	define("USER_MASTER",$table_prefix."user_master");
	define("USER",$table_prefix."user");
	
	$conn=mysqli_connect($hostname,$username,$password);
	if(mysqli_connect_error()){
		die("Database couldn't connect");
	}
	
	mysqli_select_db($conn,$databasename);
	
	
?>
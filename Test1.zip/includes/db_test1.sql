-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 11, 2018 at 02:12 PM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_test1`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `user_id` int(11) NOT NULL,
  `user_name` text NOT NULL,
  `user_email` text NOT NULL,
  `user_password` text NOT NULL,
  `isactive` int(11) NOT NULL DEFAULT '1',
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`user_id`, `user_name`, `user_email`, `user_password`, `isactive`, `created_on`) VALUES
(1, 'user123', 'miaomao@mailinator.com', 'user@123', 1, '2018-12-11 11:56:35'),
(2, 'test', 'gdfghfgh@fgh.hj', 'test@123', 1, '2018-12-11 11:58:54'),
(3, 'test123', 'automobilevendor@mailinator.com', 'test123', 1, '2018-12-11 11:59:36'),
(4, 'abcd', 'abcd@abcd.com', 'abcd', 1, '2018-12-11 11:59:51'),
(5, 'dfgdfg', 'fghfgh@fgh.fg', '12345', 1, '2018-12-11 12:01:07');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user_master`
--

CREATE TABLE `tbl_user_master` (
  `user_id` int(11) NOT NULL,
  `username` text NOT NULL,
  `password` text NOT NULL,
  `d_password` text NOT NULL,
  `isactive` int(11) NOT NULL DEFAULT '1',
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_user_master`
--

INSERT INTO `tbl_user_master` (`user_id`, `username`, `password`, `d_password`, `isactive`, `created_on`) VALUES
(1, 'user', 'ba5ef51294fea5cb4eadea5306f3ca3b', 'user@123', 1, '2018-12-11 09:59:37'),
(2, 'test', 'ceb6c970658f31504a901b89dcd3e461', 'test@123', 1, '2018-12-11 11:58:54'),
(3, 'test123', 'cc03e747a6afbbcbf8be7668acfebee5', 'test123', 1, '2018-12-11 11:59:36'),
(4, 'abcd', 'e2fc714c4727ee9395f324cd2e7f331f', 'abcd', 1, '2018-12-11 11:59:51'),
(5, 'dfgdfg', '827ccb0eea8a706c4c34a16891f84e7b', '12345', 1, '2018-12-11 12:01:07');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `tbl_user_master`
--
ALTER TABLE `tbl_user_master`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tbl_user_master`
--
ALTER TABLE `tbl_user_master`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

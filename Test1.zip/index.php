<?php
	include('common/handler.php');
	
?>
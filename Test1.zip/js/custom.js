$(document).ready(function(){
	jQuery.validator.addMethod("laxEmail", function(value, element) {
		if(value.indexOf("@")>0){
			var res = value.split("@");
			if(res[1].indexOf(".")>0){
				var res1=res[1].split(".");
				if(res1.length<=3){
					return this.optional( element ) ||  /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/.test( value );
				}else{
					return false;
				}
			}else{
				return false;
			}
		}else{
			return false;
		}
		
	}, 'Please enter a valid email address.');
});
$(document).ready(function(){
	$("#User_login").validate({
		rules:{
			txt_username:{required:true,},
			txt_password:{required:true,},
		},
		submitHandler: function(form) {
			$.ajax({
				url:"ajax/login.php",
				type:"post",
				dataType:"json",
				data: $(form).serialize(),
				success: function(response) {
					console.log(response);
					if(response==1){
						$("#LoginUnsuccess").attr("hidden",true);
						$("#LoginSuccess").attr("hidden",false);
						setTimeout(function(){
							$("#Loginsuccess").attr("hidden",true);
							window.location.href='?';
						},1000);
					}else{
						$("#Loginsuccess").attr("hidden",true);
						$("#LoginUnsuccess").attr("hidden",false);
						setTimeout(function(){
							$("#LoginUnsuccess").attr("hidden",true);
						},4000);
					}
				},
				error:function(response){
					console.log(response);
				}
			});
		},
	});
	
});
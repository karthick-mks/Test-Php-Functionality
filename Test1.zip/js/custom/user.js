$(document).ready(function(){
	
	$("#FormUserMaster").validate({
		rules:{
			UserName:{required:true,},
			UserEmail:{required:true,laxEmail:true},
			UserPassword:{required:true,},
		},
		submitHandler: function(form) {
			$.ajax({
				url:"ajax/user.php",
				type:"post",
				dataType:"json",
				data: $(form).serialize(),
				success: function(response) {
					console.log(response);
					if(response==1){
						$("#UsernameExists").attr("hidden",true);
						$("#UserSuccess").attr("hidden",false);
						setTimeout(function(){
							$("#UserSuccess").attr("hidden",true);
							window.location.href='?page=user';
						},1000);
					}else if(response==2){
						$("#UserSuccess").attr("hidden",true);
						$("#UsernameExists").attr("hidden",false);
						setTimeout(function(){
							$("#UsernameExists").attr("hidden",true);
						},4000);
					}
				},
				error:function(response){
					console.log(response);
				}
			});
		},
	});
	
	$("#FormUserMasterEdit").validate({
		rules:{
			UserNameEdit:{required:true,},
			UserEmailEdit:{required:true,laxEmail:true},
		},
		submitHandler: function(form) {
			$.ajax({
				url:"ajax/user.php",
				type:"post",
				dataType:"json",
				data: $(form).serialize(),
				success: function(response) {
					console.log(response);
					if(response==1){
						$("#UsernameExistsEdit").attr("hidden",true);
						$("#UserSuccessEdit").attr("hidden",false);
						setTimeout(function(){
							$("#UserSuccessEdit").attr("hidden",true);
							window.location.href='?page=user';
						},1000);
					}else if(response==2){
						$("#UserSuccessEdit").attr("hidden",true);
						$("#UsernameExistsEdit").attr("hidden",false);
						setTimeout(function(){
							$("#UsernameExistsEdit").attr("hidden",true);
						},4000);
					}
				},
				error:function(response){
					console.log(response);
				}
			});
		},
	});
	
	ListUserMasterDetails();
});

function ListUserMasterDetails(){
	$.ajax({
		url:"ajax/user.php",
		type:"post",
		data:{"mode":"ListUserMasterDetails"},
		dataType:"json",
		success:function(response){
			console.log(response);
			$("#UserMasterDetails").html('<table id="Datatable" class="table table-bordered"><thead><tr><th width="7%">S No.</th><th width="40%">User Name</th><th width="40%">User Email</th><th width="13%">Action</th></tr></thead><tbody id="DetailedData"></tbody></table>');
			for(var i=0;i<response.length;i++){
				$("#DetailedData").append('<tr><td align="center">'+(i+1)+'</td><td>'+response[i].user_name+'</td><td>'+response[i].user_email+'</td><td align="center"><button class="btn btn-xs btn-info btn_edit" onclick="EditUser('+response[i].user_id+');">Edit</button><button class="btn btn-xs btn-danger btn_delete" onclick="DeleteUser('+response[i].user_id+');">Delete</button></td></tr>');
			}
			$('#Datatable').DataTable();
			
		},error:function(response){
			console.log(response);
		}
	});
}

function EditUser(user_id){
	$.ajax({
		url:"ajax/user.php",
		type:"post",
		data:{"mode":"EditUser","user_id":user_id},
		dataType:"json",
		success:function(response){
			/* console.log(response); */
			if(response){
				$("#FormUserMasterEdit #UserId").val(response.user_id);
				$("#FormUserMasterEdit #UserNameEdit").val(response.user_name);
				$("#FormUserMasterEdit #UserEmailEdit").val(response.user_email);
				$("#FormUserMasterEdit #UserPasswordEdit").val('');
				$('#EditUser').modal('show');
			}
		},error:function(response){
			console.log(response);
		}
	});
}
<div class="container pt-3">
	<div class="row justify-content-sm-center">
		<div class="col-sm-6 col-md-4">
			
			<div class="card border-info text-center">
				<div class="card-header">
					Sign in to continue
				</div>
				<div class="card-body">
					<img src="images/user_access.png" style="width:150px;margin-bottom:30px;">
					<br>
					<label id="LoginSuccess" class="text-success" hidden>Login Successfully !.</label>
					<label id="LoginUnsuccess" class="text-danger" hidden>Username or Password did not match !.</label>
					<form class="form-signin User_login" method="POST" id="User_login">
						<input type="hidden" name="mode" value="UserLogin">
						<input type="text" class="form-control mb-2" name="txt_username" placeholder="Email" required >
						<input type="password" class="form-control mb-2" name="txt_password" placeholder="Password" required>
						<button class="btn btn-lg btn-primary btn-block mb-1" type="submit">Sign in</button>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
<script src='js/custom/login.js'></script>
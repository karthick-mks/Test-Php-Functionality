
<button type="button" class="btn btn-secondary mb-3" data-toggle="modal" data-target="#AddUser">Add User</button>
<div id="UserMasterDetails"></div>

<div class="modal fade" id="AddUser" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<form id="FormUserMaster">
				<div class="modal-header">
					<h5 class="modal-title" id="exampleModalLabel">Add User</h5>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
				</div>
				<div class="modal-body">
					<label class="text-success" id="UserSuccess" hidden>User Added Successfully!.</label>
					<label class="text-danger" id="UsernameExists" hidden>Username Already Exists!.</label>
					<div class="form-group row">
						<label for="UserName" class="col-sm-2 col-form-label">Name</label>
						<div class="col-sm-10">
							<input type="text" class="form-control" name="UserName" id="UserName" placeholder="Name">
						</div>
					</div>
					<div class="form-group row">
						<label for="UserEmail" class="col-sm-2 col-form-label">Email</label>
						<div class="col-sm-10">
							<input type="email" class="form-control" name="UserEmail" id="UserEmail" placeholder="email@example.com">
						</div>
					</div>
					<div class="form-group row">
						<label for="UserPassword" class="col-sm-2 col-form-label">Password</label>
						<div class="col-sm-10">
							<input type="password" class="form-control" name="UserPassword" id="UserPassword" placeholder="Password">
						</div>
					</div>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
					<input type="hidden" name="mode" value="UserMaster">
					<input type="submit" class="btn btn-sm btn-primary" id="form_submit" value="Submit">
				</div>
			</form>
		</div>
	</div>
</div>
<div class="modal fade" id="EditUser" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<form id="FormUserMasterEdit">
				<div class="modal-header">
					<h5 class="modal-title" id="exampleModalLabel">Edit User</h5>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
				</div>
				<div class="modal-body">
					<label class="text-success" id="UserSuccessEdit" hidden>User Added Successfully!.</label>
					<label class="text-danger" id="UsernameExistsEdit" hidden>Username Already Exists!.</label>
					<div class="form-group row">
						<label for="UserNameEdit" class="col-sm-2 col-form-label">Name</label>
						<div class="col-sm-10">
							<input type="text" class="form-control" name="UserNameEdit" id="UserNameEdit" placeholder="Name">
						</div>
					</div>
					<div class="form-group row">
						<label for="UserEmailEdit" class="col-sm-2 col-form-label">Email</label>
						<div class="col-sm-10">
							<input type="email" class="form-control" name="UserEmailEdit" id="UserEmailEdit" placeholder="email@example.com">
						</div>
					</div>
					<div class="form-group row">
						<label for="UserPasswordEdit" class="col-sm-2 col-form-label">Password</label>
						<div class="col-sm-10">
							<input type="password" class="form-control" name="UserPasswordEdit" id="UserPasswordEdit" placeholder="Password">
						</div>
					</div>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
					<input type="hidden" name="UserId" id="UserId">
					<input type="hidden" name="mode" value="UserMasterEdit">
					<input type="submit" class="btn btn-primary" id="formsubmit" value="Update">
				</div>
			</form>
		</div>
	</div>
</div>
<script src='js/custom/user.js'></script>